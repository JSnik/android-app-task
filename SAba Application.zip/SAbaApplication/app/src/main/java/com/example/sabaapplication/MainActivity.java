package com.example.sabaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button shesvla = findViewById(R.id.shsasvleliBtn);
        Button registracia = findViewById(R.id.registraciaBtn);
        Button ukan = findViewById(R.id.ukan);
        LinearLayout shesvlisa = findViewById(R.id.shesvla);
        LinearLayout registraciisa = findViewById(R.id.registracia);
        LinearLayout buttonisa = findViewById(R.id.buttons);

        shesvla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shesvlisa.setVisibility(View.VISIBLE);
                buttonisa.setVisibility(View.INVISIBLE);
                ukan.setVisibility(View.VISIBLE);
            }
        });
        registracia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registraciisa.setVisibility(View.VISIBLE);
                buttonisa.setVisibility(View.INVISIBLE);
                ukan.setVisibility(View.VISIBLE);
            }
        });
        ukan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registraciisa.setVisibility(View.INVISIBLE);
                shesvlisa.setVisibility(View.INVISIBLE);
                buttonisa.setVisibility(View.VISIBLE);
                ukan.setVisibility(View.INVISIBLE);
            }
        });

    }
}